from setuptools import setup, find_packages

setup(name="packagemanisha", version="0.1",
      description="This is manisha first packages", long_description="This is a very very long description", author="Manisha", packages=['packagemanisha'], install_requires=[])
