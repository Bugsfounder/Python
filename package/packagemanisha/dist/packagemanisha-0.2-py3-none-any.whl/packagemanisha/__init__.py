
class Achha:
    def __init__(self) -> None:
        print("Constructor Ban Gaya")

    def achhaFunc(self, number):
        print("This is a function")
        return number
